Submitting Date: 02/08/2024

Assignment Level: Medium

Code Quality: Maintained

Comments: Added to explain the logic and steps within the code.

Notes
Each function is provided with a brief description at the top.
Code is formatted for readability.
Variable names are chosen to be meaningful.

Run the assignment.js file as follows:-

1-> Download and install Node.js from nodejs.org.
2-> Extract the file to the desired folder.
3-> Open a command prompt in that folder.
4-> Run the script by typing node assignment.js.
